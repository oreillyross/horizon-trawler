const express = require('express')
const app = express()
const logger = require('morgan');
const { ApolloServer, gql } = require('apollo-server-express');


require('dotenv').config()


// Construct a schema, using GraphQL schema language
const typeDefs = gql`
  type Query {
    hello: String
  }
`;

// Provide resolver functions for your schema fields
const resolvers = {
  Query: {
    hello: () => 'Hello world!',
  },
};


app.use(logger('dev'));




const server = new ApolloServer({ playground: true, typeDefs, resolvers });


server.applyMiddleware({ app });

app.listen({ cors: true, port: 8080}, () =>
  console.log(`🚀 Server ready at http://localhost:8080${server.graphqlPath}`)
);











